import cv2 as cv
import numpy as np
import time
from multiprocessing import shared_memory

# sm memory 선언
print("start...")
sm_name = "PUCK"
shm_size = 4  # 4 바이트 int 1개
shm = shared_memory.SharedMemory(name=sm_name, create=True, size=shm_size)
print("sm memory is open...")


# SM memory
def send_data(shm_name, flag):
    shm = shared_memory.SharedMemory(name=shm_name)
    shared_data = np.ndarray((4), dtype='int', buffer=shm.buf)

    for i in range(len(flag)):
        print("length of flag: ", str(len(flag)))
        shared_data[i] = flag[i]


class VideoProcessor:
    
    def __init__(self, cameraNumber=2):
        self.drawing = False
        self.ix, self.iy = -1, -1
        self.fx, self.fy = -1, -1
        self.frame_hsv = None
        self.roi_hist = None
        self.user_font = cv.FONT_HERSHEY_SIMPLEX 

        self.previous_position = (0, 0)  # Initialize previous_position variable
        self.current_position = None
        self.previous_velocity = None
        self.move_right = False
        self.path_drawn_time = None
        self.path_line = None
        self.reflected_path_line = None
        self.extra_reflected_path_line = None
        self.slope = None
        self.previous_slope = None
        self.center_x = 0
        self.center_y = 0
        
        # Count the number of frames without contours
        self.no_contour = 0
        self.no_contour_flag = 0
        # slope calculate
        self.slope_list = [] 
        self.stored_position = None 
        self.flag = 0
        self.path_drawn = False
        
        self.is_goal = None
        self.shoot = 0
               
        cap = cv.VideoCapture(cameraNumber)
        fourcc = cv.VideoWriter.fourcc('M','J','P','G')
        cap.set(cv.CAP_PROP_FOURCC, fourcc)
        cap.set(cv.CAP_PROP_FPS, 60.0) 
        #cap.set(cv.CAP_PROP_AUTO_EXPOSURE, 0.75) 
        cap.set(cv.CAP_PROP_EXPOSURE, 12.0)
        print(cap.get(cv.CAP_PROP_EXPOSURE))

        if not cap.isOpened():
            print("Unable to open video file")
            
            exit()

        self.width = int(cap.get(cv.CAP_PROP_FRAME_WIDTH))
        self.height = int(cap.get(cv.CAP_PROP_FRAME_HEIGHT))
        self.fps = int(cap.get(cv.CAP_PROP_FPS))
        print("Video properties - Width:", self.width, "Height:", self.height, "FPS:", self.fps)

        self.cap = cap

        self.output_width = self.width
        self.output_height = self.height
        self.output_fps = self.fps
        self.output_filename = 'output2.mp4'
        self.output_video = cv.VideoWriter(self.output_filename, fourcc, self.output_fps, (self.output_width, self.output_height))

        cv.namedWindow('Video', cv.WINDOW_NORMAL)
        cv.resizeWindow('Video', self.width, self.height)

        cv.setMouseCallback('Video', self.select_roi)

        # field boundary
        self.line_x1 = 90
        self.line_y1 = 93
        self.line_x2 = self.width - 50
        self.line_y2 = self.height - 105  
              
    # set inrange using mouse    
    def select_roi(self, event, x, y, flags, param):
        if event == cv.EVENT_LBUTTONDOWN:
            self.drawing = True
            self.ix, self.iy = x, y
            self.fx, self.fy = x, y
            
        elif event == cv.EVENT_MOUSEMOVE:
            if self.drawing == True:
                self.fx, self.fy = x, y
                
        elif event == cv.EVENT_LBUTTONUP:
            self.drawing = False
            self.fx, self.fy = x, y
            
            hsv_roi = self.frame_hsv[self.iy:self.fy, self.ix:self.fx]
            mask = cv.inRange(hsv_roi, np.array((0., 40., 22.)), np.array((180., 255., 255.)))
            self.roi_hist = cv.calcHist([hsv_roi], [0], mask, [180], [0, 180])
            cv.normalize(self.roi_hist, self.roi_hist, 0, 255, cv.NORM_MINMAX)
    
    
            
    # trajectory slope calculation        
    def slope_avg(self, new_slope):
        # Append new_slope to the list
        if len(self.slope_list) <= 5:
            self.slope_list.append(new_slope)

        if len(self.slope_list) == 5:
            self.stored_position = self.current_position
            self.path_drawn = False  
            
        # Compute the average of the slopes
        self.slope = sum(self.slope_list) / len(self.slope_list) 
         
        
    def predict_path(self, contours):
        # initialize variables
        roi_x1 = self.line_x1
        roi_y1 = self.line_y1
        roi_x2 = self.line_x2
        roi_y2 = self.line_y2
        
        hit_border = None
        hit_border2 = None
        reflected_y2 = None
        reflected_x2 = None
        
        if contours:
            for cnt in contours:
                area = cv.contourArea(cnt)
                # filter outlier contours
                if 200 <= area <= 400:
                    x, y, w, h = cv.boundingRect(cnt)
                    # check object in roi
                    if (roi_x1 <= x <= roi_x2) and (roi_y1 <= y <= roi_y2):  
                        self.no_contour_flag = 0
                        # Calculate the center of the bounding box
                        self.center_x = x + w // 2
                        self.center_y = y + h // 2
                        self.current_position = (self.center_x, self.center_y)
                        # object target
                        cv.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                        
                        x_move = self.current_position[0] - self.previous_position[0]
                        move_distance = float(np.sqrt((self.current_position[0] - self.previous_position[0])**2+(self.current_position[1] - self.previous_position[1])**2))
                        
                        # Reset slope list and drawn paths if object moves left more than -3
                        if x_move < -3:
                            self.slope_list = []
                            self.path_line = None
                            self.reflected_path_line = None
                            self.path_drawn = False
                            self.extra_reflected_path_line = None 
            
                        # If puck is moving to the right
                        if self.previous_position is not (0,0) and x_move >= 3 and move_distance >= 4.5:
                            self.puck_move = True
                            self.slope_avg((self.current_position[1] - self.previous_position[1]) / (self.current_position[0] - self.previous_position[0]))
                        else:
                            self.puck_move = False
                        
                        # If puck is moving
                        if self.puck_move == True and len(self.slope_list) > 0 and not self.path_drawn: 
                 
                            if self.slope != 0 and self.slope < 0:
                                predicted_x = self.previous_position[0] + (roi_y1 - self.previous_position[1]) / self.slope 
                            elif self.slope != 0 and self.slope > 0:
                                predicted_x = self.previous_position[0] + (roi_y2 - self.previous_position[1]) / self.slope 
                            else:
                                predicted_x = self.previous_position[0]

                            # Ensure that predicted_x does not exceed the boundaries.
                            predicted_x = min(max(predicted_x, roi_x1), roi_x2)
                                
                            # Predicted path line (in boundary)
                            predicted_y1 = self.current_position[1] + self.slope * (roi_x1 - self.current_position[0])
                            predicted_y2 = self.current_position[1] + self.slope * (roi_x2 - self.current_position[0])
                            predicted_y1 = max(roi_y1, min(roi_y2, predicted_y1))
                            predicted_y2 = max(roi_y1, min(roi_y2, predicted_y2))

                            
                            # Remember the border (upper or lower) that was hit
                            hit_border = roi_y1 if predicted_y2 == roi_y1 else roi_y2
                            
                            if hit_border is not None and predicted_x != roi_x2:
                                if self.slope != 0:
                                    if 0 <= abs(self.slope) <= 1.5:
                                       self.slope = self.slope * 0.4 
                                    if 1.5 < self.slope <= 5:
                                       self.slope = self.slope * 0.7
                                    if -5 < self.slope <= -1.5:
                                       self.slope = self.slope * 0.8
                                      
                                    reflected_y2 = hit_border - self.slope  * (roi_x2 - self.current_position[0])
                                    reflected_x2 = self.current_position[0] + (reflected_y2 - hit_border) / -self.slope 
                                  
                                    # when hit the borders                                    
                                    if reflected_y2 >= roi_y2 and reflected_x2 <= roi_x2:
                                        reflected_y2 = roi_y2
                                        reflected_x2 = self.current_position[0] + (reflected_y2 - hit_border) / -self.slope # * 1.2 

                                    if reflected_y2 <= roi_y1 and reflected_x2 <= roi_x2:
                                        reflected_y2 = roi_y1
                                        reflected_x2 = self.current_position[0] + (reflected_y2 - hit_border) / -self.slope
                                    
                                if reflected_x2 is not None and reflected_y2 is not None:
                                    self.reflected_path_line = ((int(predicted_x), int(predicted_y2)), (int(reflected_x2), int(reflected_y2)))
                                else:
                                    self.reflected_path_line = None
                                    
                            else:
                                self.reflected_path_line = None
                            
                            if reflected_y2 is not None:
                                hit_border2 = roi_y1 if reflected_y2 == roi_y1 else roi_y2

                            if hit_border2 is not None and reflected_x2 != roi_x2:
                                reflected_x3 = roi_x2
                                reflected_y3_temp = hit_border2 + self.slope *  (roi_x2 - reflected_x2)  # reflection
                                
                                # reflected_y3_temp will be bounded by the ROI borders
                                reflected_y3 = max(roi_y1, min(roi_y2, reflected_y3_temp))

                            
                                self.extra_reflected_path_line = ((int(reflected_x2), int(reflected_y2)), (int(reflected_x3), int(reflected_y3)))
                            else:
                                self.extra_reflected_path_line = None

                            self.path_line = ((self.current_position[0], self.current_position[1]), (int(predicted_x), int(predicted_y2)))
                            
                            self.path_drawn = True
                            
                        else:
                            # Reset paths
                            self.predicted_path = None
                            self.reflected_path = None
                            

                        self.previous_position = self.current_position
                        self.path_drawn_time = time.time()
           
                    

    def goal(self):
        goal_x = self.line_x2
        goal_y1 = 0
        goal_y2 = self.height
        
        #cv.line(frame, (goal_x, goal_y1), (goal_x, goal_y2), (0, 255, 0), 1)

        # Check if self.center_x has passed the goal line
        if self.center_x >= goal_x:
            
            # If this state continues for more than 180 frames, set the flag to 6
            if self.no_contour > 200:
                self.path_line = None
                self.relfected_path_line = None
                self.extra_reflected_path_line = None
                self.flag = 4
                self.is_goal = True

                if self.no_contour == 200:
                    self.shoot += 1
                cv.putText(frame, "Flag: " + str(self.flag), (450,80), self.user_font, 0.7, (255, 255, 0), 2)
                print(self.is_goal)
            else:
                self.is_goal = False

            if self.no_contour > 600:
                self.no_contour = 0
                self.no_contour_flag = 1
                
                
        else:
            # Reset the no_contour counter if the object is not past the goal line
            self.no_contour = 0
            self.no_contour_flag = 1
            
        if self.flag == 4:
            cv.putText(frame, "---- YOU WIN ----", (220,200), self.user_font, 0.7, (255, 255, 255), 3)
            cv.putText(frame, "---- YOU WIN ----", (220,200), self.user_font, 0.7, (0, 0, 0), 2)

    def decide_flag(self):
        roi_width = self.line_y2 - self.line_y1
        y_div = roi_width // 5
        
        # set the flag area
        robot_area1 = [int(self.width / 10 * 9), self.line_y1, self.width, self.line_y1 + y_div * 2]
        robot_area2 = [int(self.width / 10 * 9), self.line_y1 + y_div * 2, self.width, self.line_y1 + 3 * y_div]
        robot_area3 = [int(self.width / 10 * 9), self.line_y1 + 3 * y_div, self.width, self.line_y2]
        
        cv.rectangle(frame, (robot_area1[0], robot_area1[1]), (robot_area1[2], robot_area1[3]), (255, 255, 255), 2)
        cv.rectangle(frame, (robot_area2[0], robot_area2[1]), (robot_area2[2], robot_area2[3]), (255, 255, 255), 2)
        cv.rectangle(frame, (robot_area3[0], robot_area3[1]), (robot_area3[2], robot_area3[3]), (255, 255, 255), 2)

        final_point = None
        
        # set final point 
        if self.path_line is not None and self.reflected_path_line is None:
            final_point = self.path_line[1]  

        if self.reflected_path_line is not None:
            final_point = self.reflected_path_line[1]  

        if self.extra_reflected_path_line is not None:
            final_point = self.extra_reflected_path_line[1]  

        # check final point position in robot area    
        if final_point:
            
            if robot_area1[1] <= final_point[1] <= robot_area1[3]:
                self.flag = 1
                cv.rectangle(frame, (robot_area1[0], robot_area1[1]), (robot_area1[2], robot_area1[3]), (255, 151, 153), 5)
            elif robot_area2[1] <= final_point[1] <= robot_area2[3]:
                self.flag = 2
                cv.rectangle(frame, (robot_area2[0], robot_area2[1]), (robot_area2[2], robot_area2[3]), (255, 151, 153), 5)
            elif robot_area3[1] <= final_point[1] <= robot_area3[3]:
                self.flag = 3
                cv.rectangle(frame, (robot_area3[0], robot_area3[1]), (robot_area3[2], robot_area3[3]), (255, 151, 153), 5)
                
            cv.putText(frame, "Flag: " + str(self.flag), (450,50), self.user_font, 0.7, (255, 255, 0), 2)


        # shared memory send data to indy10
        send_data(sm_name, self.flag)            
                                               
    def process_video(self):
        while True:
            global frame
            start_time = time.time()
            ret, frame = self.cap.read()

            if not ret:
                print("End of video")
                break

            #frame = cv.flip(frame, 1)
            self.frame_hsv = cv.cvtColor(frame, cv.COLOR_BGR2HSV)

            #cv.line(frame, (self.line_x1, self.line_y1), (self.line_x2, self.line_y1), (153, 0, 204), 2)
            #cv.line(frame, (self.line_x1, self.line_y2), (self.line_x2, self.line_y2), (153, 0, 204), 2)
            
            # show filed area
            overlay = frame.copy()
            cv.rectangle(overlay, (25, 93), (self.width - 20, self.height - 105), (204, 153, 255), -1)
            cv.rectangle(frame, (25, 93), (self.width - 20, self.height - 105), (102, 51, 204), 2)
            transparency = 0.2
            frame = cv.addWeighted(overlay, transparency, frame, 1 - transparency, 0)

            start_line = np.array([(110, self.line_y1), (110, self.line_y2)])      
            
            cv.putText(frame, "Shoot Line", (60,75), self.user_font, 0.7, (255, 255, 255), 3)
            cv.putText(frame, "Shoot Line", (60,75), self.user_font, 0.7, (0, 0, 0), 2)
            cv.line(frame, (start_line[0]), (start_line[1]), (100, 255, 40), 1)
            
            if self.drawing:
                cv.rectangle(frame, (self.ix, self.iy), (self.fx, self.fy), (255, 0, 0), 2)

            if self.roi_hist is not None:
                back_proj = cv.calcBackProject([self.frame_hsv], [0], self.roi_hist, [0, 180], 1)
                _, threshold = cv.threshold(back_proj, 1, 255, cv.THRESH_BINARY)
                contours, _ = cv.findContours(threshold, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)

                # puck detection 
                detected = False
                for contour in contours:
                    area = cv.contourArea(contour)
                    
                    if 100 < area < 300:
                        
                        detected = True
                        self.no_contour_flag == 1
                        break

                # no contour count
                if detected != True and self.no_contour_flag == 0:
                    self.no_contour += 1
                    self.no_contour_flag == 0   
                
                else:
                    self.no_contour = 0
                    self.no_contour_flag == 1
    
                self.predict_path(contours)
            
            if self.path_line is not None: 
                cv.line(frame, *self.path_line, (204, 102, 000), 2)
            if self.reflected_path_line is not None:
                cv.line(frame, *self.reflected_path_line, (204, 102, 000), 2)
            if self.extra_reflected_path_line is not None:
                cv.line(frame, *self.extra_reflected_path_line, (204, 102, 000), 2)

            if self.is_goal == True and self.shoot == 1:
                cv.circle(frame,(20.20), 10, (0,255,0), 2)
            elif self.is_goal == False and self.shoot == 1:
                cv.circle(frame,(20.20), 10, (0,0,255), 2)


            self.goal()
            self.decide_flag()
  
            diff_time = time.time() - start_time

            if diff_time > 0:
                fps = 1 / diff_time


            cv.imshow("Video", frame)

            self.output_video.write(frame)
        
            key = cv.waitKey(1) & 0xFF
            if key == ord('q')   :   break
            

        self.cap.release()
        self.output_video.release()
        cv.destroyAllWindows()



if __name__ == "__main__":
    processor = VideoProcessor()
    processor.process_video()