// Auto-generated. Do not edit!

// (in-package indy_driver.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class grip_state {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.change = null;
      this.on = null;
    }
    else {
      if (initObj.hasOwnProperty('change')) {
        this.change = initObj.change
      }
      else {
        this.change = 0;
      }
      if (initObj.hasOwnProperty('on')) {
        this.on = initObj.on
      }
      else {
        this.on = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type grip_state
    // Serialize message field [change]
    bufferOffset = _serializer.char(obj.change, buffer, bufferOffset);
    // Serialize message field [on]
    bufferOffset = _serializer.char(obj.on, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type grip_state
    let len;
    let data = new grip_state(null);
    // Deserialize message field [change]
    data.change = _deserializer.char(buffer, bufferOffset);
    // Deserialize message field [on]
    data.on = _deserializer.char(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 2;
  }

  static datatype() {
    // Returns string type for a message object
    return 'indy_driver/grip_state';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b1a215b77e77f0cb59e72837acd5ddc5';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    char change
    char on
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new grip_state(null);
    if (msg.change !== undefined) {
      resolved.change = msg.change;
    }
    else {
      resolved.change = 0
    }

    if (msg.on !== undefined) {
      resolved.on = msg.on;
    }
    else {
      resolved.on = 0
    }

    return resolved;
    }
};

module.exports = grip_state;
