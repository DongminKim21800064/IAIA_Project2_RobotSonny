// Auto-generated. Do not edit!

// (in-package indy_driver.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class grip_command {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.DO_Pin0 = null;
      this.DO_Pin1 = null;
      this.DO_Val0 = null;
      this.DO_Val1 = null;
    }
    else {
      if (initObj.hasOwnProperty('DO_Pin0')) {
        this.DO_Pin0 = initObj.DO_Pin0
      }
      else {
        this.DO_Pin0 = 0;
      }
      if (initObj.hasOwnProperty('DO_Pin1')) {
        this.DO_Pin1 = initObj.DO_Pin1
      }
      else {
        this.DO_Pin1 = 0;
      }
      if (initObj.hasOwnProperty('DO_Val0')) {
        this.DO_Val0 = initObj.DO_Val0
      }
      else {
        this.DO_Val0 = 0;
      }
      if (initObj.hasOwnProperty('DO_Val1')) {
        this.DO_Val1 = initObj.DO_Val1
      }
      else {
        this.DO_Val1 = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type grip_command
    // Serialize message field [DO_Pin0]
    bufferOffset = _serializer.int8(obj.DO_Pin0, buffer, bufferOffset);
    // Serialize message field [DO_Pin1]
    bufferOffset = _serializer.int8(obj.DO_Pin1, buffer, bufferOffset);
    // Serialize message field [DO_Val0]
    bufferOffset = _serializer.char(obj.DO_Val0, buffer, bufferOffset);
    // Serialize message field [DO_Val1]
    bufferOffset = _serializer.char(obj.DO_Val1, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type grip_command
    let len;
    let data = new grip_command(null);
    // Deserialize message field [DO_Pin0]
    data.DO_Pin0 = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [DO_Pin1]
    data.DO_Pin1 = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [DO_Val0]
    data.DO_Val0 = _deserializer.char(buffer, bufferOffset);
    // Deserialize message field [DO_Val1]
    data.DO_Val1 = _deserializer.char(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'indy_driver/grip_command';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b6a07f7d6a260f4103a377592da27b77';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int8 DO_Pin0
    int8 DO_Pin1
    char DO_Val0
    char DO_Val1
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new grip_command(null);
    if (msg.DO_Pin0 !== undefined) {
      resolved.DO_Pin0 = msg.DO_Pin0;
    }
    else {
      resolved.DO_Pin0 = 0
    }

    if (msg.DO_Pin1 !== undefined) {
      resolved.DO_Pin1 = msg.DO_Pin1;
    }
    else {
      resolved.DO_Pin1 = 0
    }

    if (msg.DO_Val0 !== undefined) {
      resolved.DO_Val0 = msg.DO_Val0;
    }
    else {
      resolved.DO_Val0 = 0
    }

    if (msg.DO_Val1 !== undefined) {
      resolved.DO_Val1 = msg.DO_Val1;
    }
    else {
      resolved.DO_Val1 = 0
    }

    return resolved;
    }
};

module.exports = grip_command;
