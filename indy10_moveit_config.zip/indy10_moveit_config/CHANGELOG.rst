^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package indy10_moveit_config
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.3 (2019-01-18)
------------------
* Fixed xacro loadding for planning context
* Fixed indy_driver for 7-dof robot
* Contributors: Thach Do

1.0.2 (2019-01-08)
------------------
* Fixed packages' information
* Contributors: Thach Do

1.0.1 (2019-01-08)
------------------
* Initialize Indy repository for ROS community
* Contributors: Thach Do
